Envato Standard License

Copyright (c) Withinpixels <hi@withinpixels.com>

This project is protected by Envato's Standard License. For more information,
check the official license page at [https://themeforest.net/licenses/standard](https://themeforest.net/licenses/standard)
